﻿using System;

namespace Entities
{
    public class Log
    {
        public int Id { get; set; }
        public string LogDate { get; set; }
        public string LogMessage { get; set; }
    }
}
