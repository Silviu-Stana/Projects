﻿using EstateModels;

namespace EstateDataAccess.Repository.SqlRepository
{
    public class EstateRepository : SQLRepository<Estate>
    {

    }
}