﻿using EstateModels;
using System;
using System.Collections.Generic;

namespace EstateDataAccess.Repository.SqlRepository
{
    internal class JsonRepository : SQLRepository<Estate>
    {
        public Owner Create(Owner value)
        {
            throw new NotImplementedException();
        }

        public Owner Update(Owner value)
        {
            throw new NotImplementedException();
        }
    }
}