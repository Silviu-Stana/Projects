﻿using EstateModels;

namespace EstateDataAccess.Repository.SqlRepository
{
    public class OwnerRepository : SQLRepository<Owner>
    {

    }
}