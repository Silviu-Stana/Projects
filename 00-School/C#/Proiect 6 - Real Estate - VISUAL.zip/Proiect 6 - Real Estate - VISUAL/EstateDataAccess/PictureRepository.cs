﻿using EstateDataAccess;
using EstateDataAccess.Repository;
using EstateModels;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace EstateDataAccess.Repository.SqlRepository
{
    public class PictureRepository : SQLRepository<Picture>
    {

    }
}
