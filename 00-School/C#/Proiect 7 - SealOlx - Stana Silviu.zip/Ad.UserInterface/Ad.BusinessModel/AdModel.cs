﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ad.BusinessModel
{
    public class AdModel
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public Category Category { get; set; }
        public int UserId { get; set; }
        public List<PictureModel> Pictures { get; set; } = new List<PictureModel>();
        public string Phone { get; set; }
    }
}
