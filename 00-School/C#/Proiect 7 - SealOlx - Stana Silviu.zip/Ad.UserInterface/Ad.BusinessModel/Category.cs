﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ad.BusinessModel
{
    public enum Category
    {
        None,
        Furniture,
        Books,
        Cars,
        Electronics,
        Sports,
        MusicalInstruments,
        HomeAppliances,
        Cleaning,
        Clothing,
        Cooking,
        Seal
    }
}

public class EnumDisplayNameAttribute : Attribute
{
    public string DisplayName { get; }

    public EnumDisplayNameAttribute(string displayName)
    {
        DisplayName = displayName;
    }
}