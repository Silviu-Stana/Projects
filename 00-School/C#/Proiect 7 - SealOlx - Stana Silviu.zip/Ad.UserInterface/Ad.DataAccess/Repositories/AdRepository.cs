﻿using Ad.BusinessModel;
using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Ad.DataAccess.Repositories
{
    public class AdRepository : IRepository<AdModel>
    {
        public string ConnectionString = ConfigurationManager.ConnectionStrings["Connection"].ConnectionString;

        public AdModel Create(AdModel value)
        {
            using (IDbConnection db = new SqlConnection(ConnectionString))
            {
                if (db.State == ConnectionState.Closed) db.Open();
                var query = @"
                    INSERT INTO Ad(Title,Description,Price,Category,UserId,Phone) 
                    VALUES(@Title,@Description,@Price,@Category,@UserId,@Phone);
                    SELECT CAST(SCOPE_IDENTITY() as int)";

                //Get back newly created id
                var id = db.Query<int>(query, new { value.Title, value.Description, value.Price, Category = value.Category.ToString(), value.UserId, value.Phone }).Single();
                value.Id = id;
                return value;
            }
        }

        public void Delete(int id)
        {
            using (IDbConnection db = new SqlConnection(ConnectionString))
            {
                if (db.State == ConnectionState.Closed) db.Open();
                db.Query<AdModel>($"DELETE FROM Ad WHERE Id={id}", commandType: CommandType.Text);
            }
        }

        public List<AdModel> GetAll()
        {
            using (IDbConnection db = new SqlConnection(ConnectionString))
            {
                if (db.State == ConnectionState.Closed) db.Open();
                return db.Query<AdModel>("SELECT * FROM Ad", commandType: CommandType.Text).ToList();
            }
        }

        public AdModel GetById(int id)
        {
            using (IDbConnection db = new SqlConnection(ConnectionString))
            {
                if (db.State == ConnectionState.Closed) db.Open();
                return db.QueryFirstOrDefault<AdModel>($"SELECT * FROM Ad WHERE Id={id}");
            }
        }

        public List<AdModel> GetByTitlePattern(string pattern, string ProductCategory)
        {
            using (IDbConnection db = new SqlConnection(ConnectionString))
            {
                if (db.State == ConnectionState.Closed) db.Open();

                if (ProductCategory == "" || ProductCategory == null || ProductCategory == "None")
                    return db.Query<AdModel>(
                        "SELECT * FROM Ad WHERE LOWER(Title) LIKE LOWER(@Pattern)",
                        new { Pattern = $"%{pattern}%" }
                    ).ToList();
                else
                    return db.Query<AdModel>(
                    "SELECT * FROM Ad WHERE LOWER(Title) LIKE LOWER(@Pattern) AND Category=@ProductCategory",
                    new { Pattern = $"%{pattern}%", ProductCategory }
                ).ToList();
            }
        }

        public AdModel Update(AdModel value)
        {
            using (IDbConnection db = new SqlConnection(ConnectionString))
            {
                if (db.State == ConnectionState.Closed) db.Open();
                var query = "UPDATE Ad SET Title=@Title, Description=@Description, Price=@Price, Category=@Category, UserId=@UserId, Phone=@Phone WHERE Id=@Id";
                db.Execute(query, new { value.Title, value.Description, value.Price, Category = value.Category.ToString(), value.UserId, value.Phone, value.Id });
                return value;
            }
        }
    }
}
