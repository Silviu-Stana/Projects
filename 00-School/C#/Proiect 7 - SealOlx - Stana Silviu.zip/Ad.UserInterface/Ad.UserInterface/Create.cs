﻿using Ad.BusinessModel;
using Ad.DataAccess.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ad.UserInterface
{
    public partial class Create : Form
    {
        bool isEditMode = false;
        int UserIdIs = 0, AdIdIs = 0;

        public Create(int AdId, int UserId)
        {
            InitializeComponent();

            UserIdIs = UserId;
            AdIdIs = AdId;

            if (AdId > 0) isEditMode = true;

            if (isEditMode) LoadAdData(AdId);

        }

        private async void LoadAdData(int AdId)
        {
            var pictureRepository = new PictureRepository();
            var picture = await Task.Run(() => pictureRepository.GetById(AdId));

            var adRepository = new AdRepository();
            var ad = await Task.Run(() => adRepository.GetById(AdId));

            TitleBox.Text = ad.Title;
            DescBox.Text = ad.Description;
            PriceBox.Text = ad.Price.ToString();
            PhoneBox.Text = ad.Phone;
            SearchCategory.Text = ad.Category.ToString();

            flowLayoutPanel1.AutoScroll = true;
            flowLayoutPanel1.FlowDirection = FlowDirection.LeftToRight;
            flowLayoutPanel1.WrapContents = false;

            DisplayAllPictures(AdId);
        }

        void DisplayAllPictures(int adId)
        {
            string folderPath = Path.Combine("Pictures", adId.ToString());
            if (Directory.Exists(folderPath))
            {
                var files = Directory.GetFiles(folderPath);
                for (int i = 0; i < files.Length; i++)
                {
                    //MemoryStream PREVENTS ERRORS WHEN COPYING FROM ONE DIRECTORY TO ANOTHER
                    using (var stream = new MemoryStream(File.ReadAllBytes(files[i])))
                    {
                        PictureComponent pic = new PictureComponent
                        {
                            ProductImage = Image.FromStream(stream)
                        };
                        flowLayoutPanel1.Controls.Add(pic);
                    }
                }
            }
        }

        bool HaveAtLeast1Picture()
        {
            return flowLayoutPanel1.Controls.Count > 0;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Create_Load(object sender, EventArgs e)
        {
            foreach (Category item in Enum.GetValues(typeof(Category)))
            {
                SearchCategory.Items.Add(item.ToString());
            }
        }

        private void Publish_Click(object sender, EventArgs e)
        {
            if (!HaveAtLeast1Picture())
            {
                MessageBox.Show("You must have at least 1 picture!");
                return;
            }

            if (TitleBox.Text.Length < 2)
            {
                MessageBox.Show("TITLE Required!");
                return;
            }

            if (DescBox.Text.Length < 1)
            {
                MessageBox.Show("DESCRIPTION Required");
                return;
            }

            if (PriceBox.Text.Length < 1)
            {
                MessageBox.Show("PRICE Required");
                return;
            }

            if (PhoneBox.Text.Length < 6 || PhoneBox.Text.Length > 15)
            {
                MessageBox.Show("PHONE Required\nMin 6 digits.\nMax 15 digits.");
                return;
            }

            if (SearchCategory.Text == "")
            {
                MessageBox.Show("You must select a CATEGORY");
                return;
            }

            if (!decimal.TryParse(PriceBox.Text, out decimal price) || price > 99999999.99m)
            {
                MessageBox.Show("PRICE must be LESS than 1 Billion DOLLARS\n(haha)");
                return;
            }


            if (isEditMode)
            {
                UpdateAd();
            }
            else
            {
                CreateAd();
            }
        }

        private async void UpdateAd()
        {
            var adRepository = new AdRepository();

            var ad = new AdModel()
            {
                Id = AdIdIs,
                Title = TitleBox.Text,
                Description = DescBox.Text,
                Price = Convert.ToDouble(PriceBox.Text),
                UserId = UserIdIs,
                Category = (Category)Enum.Parse(typeof(Category), SearchCategory.Text), // Corrected to use the parsed enum value. Uploads it as string.
                Phone = PhoneBox.Text
            };
            await Task.Run(() => adRepository.Update(ad));

            this.Close();
        }

        private async void CreateAd()
        {
            var adRepository = new AdRepository();

            var ad = new AdModel()
            {
                Id = 0,
                Title = TitleBox.Text,
                Description = DescBox.Text,
                Price = Convert.ToDouble(PriceBox.Text),
                UserId = UserIdIs,
                Category = (Category)Enum.Parse(typeof(Category), SearchCategory.Text),
                Phone = PhoneBox.Text
            };

            AdModel NewlyCreatedAdd = new AdModel();
            NewlyCreatedAdd = await Task.Run(() => adRepository.Create(ad));

            AdIdIs = NewlyCreatedAdd.Id;

            // Copy pictures from Temp folder to Pictures/{AdId}
            SaveUploadedPictures();

            this.Close();
        }

        void SaveUploadedPictures()
        {
            string tempDirectory = Path.Combine("Pictures", "Temp", UserIdIs.ToString());
            string targetDirectory = Path.Combine("Pictures", AdIdIs.ToString());

            if (Directory.Exists(tempDirectory))
            {
                if (!Directory.Exists(targetDirectory)) Directory.CreateDirectory(targetDirectory);

                var files = Directory.GetFiles(tempDirectory);
                foreach (var file in files)
                {
                    string fileName = Path.GetFileName(file);
                    string destFile = Path.Combine(targetDirectory, fileName);


                    File.Move(file, destFile);
                }

                flowLayoutPanel1.Controls.Clear();
                Directory.Delete(tempDirectory, true);
            }
        }

        private void UploadPicture_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image Files (*.jpg;*.png)|*.jpg;*.png";
                openFileDialog.Multiselect = false;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string selectedFilePath = openFileDialog.FileName;
                    int userId = UserIdIs;
                    string guid = Guid.NewGuid().ToString();
                    string fileExtension = Path.GetExtension(selectedFilePath);
                    string targetDirectory = Path.Combine("Pictures", "Temp", userId.ToString());
                    string targetFileName = $"{guid}{fileExtension}";
                    string targetFilePath = Path.Combine(targetDirectory, targetFileName);

                    if (!Directory.Exists(targetDirectory))
                    {
                        Directory.CreateDirectory(targetDirectory);
                    }

                    File.Copy(selectedFilePath, targetFilePath);

                    //MEMORY STREAM TO PREVENT ERRORS WHEN COPYING FROM ONE DIRECTORY TO ANOTHER
                    using (var stream = new MemoryStream(File.ReadAllBytes(targetFilePath)))
                    {
                        PictureComponent pic = new PictureComponent
                        {
                            ProductImage = Image.FromStream(stream)
                        };
                        flowLayoutPanel1.Controls.Add(pic);
                    }
                }
            }
        }

        private void PriceBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PriceBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow (delete)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Block non-numeric input
            }
        }

        private void PhoneBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow (delete)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Block non-numeric input
            }
        }

        private void SearchCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
