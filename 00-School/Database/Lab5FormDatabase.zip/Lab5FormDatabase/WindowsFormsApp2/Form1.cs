﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WindowsFormsApp2.Program;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        DbSqlServer dbSQL;
        public Form1()
        {
            dbSQL = new DbSqlServer();
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        //INSERT
        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && textBox2.Text != "") {
                try
                {
                    int id = int.Parse(textBox1.Text);
                dbSQL.Insert(textBox1.Text, textBox2.Text, textBox3.Text);
                }
                catch (Exception er){
                    MessageBox.Show(er.Message + "\n" + "Eroare in conversie int to string pentru");
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1 != null) dbSQL.Delete(textBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1 != null) dbSQL.Update(textBox1.Text, textBox2.Text, textBox3.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String stringConectare = "Data Source=VIRTUALDB1;Initial Catalog=dbstudentiStana2024;User ID=student;Password=Student_2023";
            SqlConnection con;
            
            try
            {
                con = new SqlConnection(stringConectare);

                String selectComanda = "select * from dbo.tClienti";
                SqlDataAdapter dataAdapter = new SqlDataAdapter(selectComanda, con);
                DataTable table = new DataTable();
                dataAdapter.Fill(table);

                dataGridView1.DataSource = table;
            }
            catch(Exception er)
            {
                MessageBox.Show(er.Message);
            }

        }
    }
}
