﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    internal static class Program
    {
        public class DbSqlServer
        {
            String stringConectare = "Data Source=VIRTUALDB1;Initial Catalog=dbstudentiStana2024;User ID=student;Password=Student_2023";
            SqlConnection con;

            public DbSqlServer()
            {
                try
                {
                    con = new SqlConnection(stringConectare);
                    con.Open();


                    Console.WriteLine("Success Connection");
                }
                catch { Console.WriteLine("Esec conectare!"); }
                con.Close();
            }

            public void Insert(string codClient, string numeClient, string localitate)
            {
                string comandaInsert = "insert into dbo.tClienti(codClient,nume,localitate) values (" + "'" + codClient + "', '" + numeClient + "', '" + localitate + "')";

                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(comandaInsert, con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Inserare cu Success");
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
                    con.Close();
            }

            public void Update(string codClient, string numeClient, string localitate)
            {
                string comandaUpdate = "update dbo.tClienti set nume='" + numeClient + "',localitate='" + localitate + "' where codClient='" + codClient + "'";


                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(comandaUpdate, con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Update cu Success");
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
                con.Close();
            }

            public void Delete(string codClient)
            {
                string comandaDelete = "delete dbo.tClienti where codClient=" + codClient;

                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand(comandaDelete, con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Stergere cu Success");
                    con.Close();
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }

        }



        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
