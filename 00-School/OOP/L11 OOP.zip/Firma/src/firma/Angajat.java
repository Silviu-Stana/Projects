package firma;
abstract public class Angajat implements Persoana, Programator {
    
    protected String nume;
    protected int varsta, vechime;
    protected boolean studii;
    
    public Angajat(String nume, int varsta, int vechime, boolean studii)
    {
        this.nume = nume;
        this.varsta = varsta;
        this.vechime = vechime;
        this.studii = studii;
    }
    
    public String getNume(){return nume;}
    public int getVarsta(){return varsta;}
    public float bonus()
    {
        if(studii==true)
        {
            return vechime * 20;
        }
        return 0;
    }
    
    abstract float salariu();
}
