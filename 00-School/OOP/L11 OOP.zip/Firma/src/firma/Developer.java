package firma;
public class Developer extends Angajat {
    int h;
    
    
    public Developer(String n, int varsta, int vechime, boolean studii, int h)
    {
        super(n, varsta, vechime, studii);
        this.h = h;
    }
    
    public float salariu()
    {
        return h * 20 + bonus();
    }
}
