package firma;

/*
class Tester extends Angajat
    bug
    constructor
    salariu()

class GestiuneAngajati
    nr, Angajat[] listaAngajati
    adauga(), afis()
*/

interface Persoana
{    
    String getNume();
    int getVarsta();
}

interface Programator
{
    float bonus();
}

public class Firma {
    public static void main(String[] args) {

        GestiuneAngajati gestiune = new GestiuneAngajati(10);
        
        Developer dev = new Developer("Mihai",30,5,true,80);
        Angajat tester = new Tester("Sergiu",25,1,false,160);
        
        gestiune.adauga(dev);
        gestiune.adauga(tester);
        gestiune.afis();
    }
    
}
