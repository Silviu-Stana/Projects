package firma;

public class GestiuneAngajati {
    private int nr;
    private Angajat[] angajati;
    
    public GestiuneAngajati(int MAX)
    {
        nr =0;
        angajati = new Angajat[MAX];
    }
    
    public void adauga(Angajat a)
    {
        if(nr<angajati.length)
        {
            angajati[nr]=a;
            nr++;
        }
        else
        {
            System.out.println("Atins nr MAX de angajati.");
        }
    }
    
    public void afis()
    {
        for(int i = 0; i < nr; i++)
        { 
            System.out.println(angajati[i].getNume() + " " + angajati[i].salariu());
        }
    }
}
