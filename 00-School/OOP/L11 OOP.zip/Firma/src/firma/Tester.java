package firma;
public class Tester extends Angajat {
    
    int bug;
    
    public Tester(String n, int varsta, int vechime, boolean studii, int bug)
    {
        super(n,varsta,vechime,studii);
        this.bug=bug;
    }
    
    
    public float salariu()
    {
        return bug * 10 + bonus();
    }
}
