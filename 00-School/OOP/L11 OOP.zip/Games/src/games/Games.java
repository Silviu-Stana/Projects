package games;

interface Lupta
{
    void fight();
}

interface Innoata
{
    void swim();
}

interface Zboara
{
    void fly();
}

class ActionCharacter
{
    public void fight()
    {
        System.out.println("ActionCharacter: fight");
    }
}

class Hero extends ActionCharacter implements Lupta, Zboara, Innoata
{
    //fight() is already implemented in Parent class, so we only need to implement the other 2
    public void swim()
    {
        System.out.println("Hero: swim");
    }
    
    public void fly()
    {
        System.out.println("Hero: fly");
    }
    
    public void fight()
    {
        System.out.println("Hero: fight");
    }
}

public class Games {

    static void t(Lupta x)
    {
        x.fight();
    }
    
    static void u(Zboara x)
    {
        x.fly();
    }
    
    static void v(Innoata x)
    {
        x.swim();
    }
    
    static void w(ActionCharacter x)
    {
        x.fight();
    }
    
    public static void main(String[] args) {
        
        Hero erou = new Hero();
        
        t(erou);
        u(erou);
        v(erou);
        w(erou);
    }
}
