package intefata;

    interface InterfA
    {
        int i=5;
        void afis();
    }
    
    class A implements InterfA
    {
        int i=6;
        public void afis()
        {
            System.out.println("Afis din clasa A= " + i + " " + InterfA.i);
        }
    }

    class B implements InterfA
    {
        int i=7;
        public void afis()
        {
            System.out.println("Afis din clasa B= " + i + " " + InterfA.i);
        }
    }

public class Intefata {
    public static void main(String[] args) {
        
        A x = new A();
        x.afis();
        
        B y = new B();
        y.afis();
        
        InterfA x1= new A();
        InterfA x2= new B();
        
        x1.afis();
    }
    
}
