package pasarile;

interface Fly
{
    void fly();
}

interface Swim
{
    void swim();
}

class Pasare implements Fly, Swim
{
    public void fly()
    {
        System.out.println("Bird flies");
    }
    
    public void swim()
    {
        System.out.println("Bird swims");
    }
}

public class Pasarile {

    public static void main(String[] args) {
        Pasare p1 = new Pasare();
        
        p1.fly();
        p1.swim();
    }
    
}
